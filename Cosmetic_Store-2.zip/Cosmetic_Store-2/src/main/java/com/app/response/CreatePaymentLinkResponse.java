package com.app.response;

public class CreatePaymentLinkResponse {
	
	

}
