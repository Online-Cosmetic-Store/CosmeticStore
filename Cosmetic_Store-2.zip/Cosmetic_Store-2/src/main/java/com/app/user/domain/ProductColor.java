package com.app.user.domain;

public enum ProductColor {

	 	BLACK,
	    WHITE,
	    RED,
	    GREEN,
	    BLUE,
	    YELLOW,
	    PINK,
	    PURPLE,
	    ORANGE,
	    GREY,
	    BROWN,
	    GOLD,
	    SILVER
}
