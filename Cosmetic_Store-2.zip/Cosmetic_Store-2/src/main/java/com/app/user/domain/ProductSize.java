package com.app.user.domain;

public enum ProductSize {

	 	
	    S,
	    M,
	    L
	  
}
