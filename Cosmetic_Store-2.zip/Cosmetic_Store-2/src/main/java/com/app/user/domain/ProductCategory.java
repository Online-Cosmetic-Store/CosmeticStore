package com.app.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
