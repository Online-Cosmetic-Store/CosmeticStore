package com.app.user.domain;

public enum ProductSubCategory {
	
	MAKEUP,
	SKIN,
	FACE,
	NAILS,
	EYES,
	

}
