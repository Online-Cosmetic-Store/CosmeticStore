package com.app.request;

public class DeleteProductRequest {
	
//	private Long 

}
